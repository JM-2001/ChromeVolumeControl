(function() {
  let c = null, i = null, s = [], u = 100;
  function f(e) {
    return typeof e == "number" && !isNaN(e) && e >= 0 && e <= 100;
  }
  function g() {
    if (!c)
      try {
        c = new AudioContext(), i = c.createGain(), i.gain.value = 1, i.connect(c.destination), d(u), console.log("Audio context initialized");
      } catch (e) {
        console.error("Error initializing AudioContext:", e);
      }
  }
  function d(e) {
    if (!f(e)) {
      console.error("Invalid volume value:", e);
      return;
    }
    if (!i) {
      u = e;
      return;
    }
    const r = e / 100;
    i.gain.value = r, u = e, console.log(`Volume set to ${e}%`);
  }
  function l() {
    if (!(!c || !i))
      try {
        const r = Array.from(
          document.querySelectorAll("audio, video")
        ).filter((o) => o instanceof HTMLMediaElement).filter(
          (o) => !s.includes(o) && o.src !== ""
        );
        r.forEach((o) => {
          try {
            if (!(o instanceof HTMLMediaElement)) {
              console.warn("Not a valid media element:", o);
              return;
            }
            if (!document.contains(o)) {
              console.warn("Element not in DOM:", o);
              return;
            }
            c.createMediaElementSource(o).connect(i), s.push(o), console.log("Connected audio element to gain node");
          } catch (n) {
            console.error("Error connecting audio element:", n);
          }
        }), r.length > 0 && h("updateTabStatus", { hasAudio: !0 });
      } catch (e) {
        console.error("Error in findAndConnectAudio:", e);
      }
  }
  function h(e, r = {}) {
    try {
      typeof chrome < "u" && chrome.runtime && chrome.runtime.sendMessage({ action: e, ...r }, function(o) {
        if (chrome.runtime.lastError) {
          console.error("Error sending message:", chrome.runtime.lastError);
          return;
        }
      });
    } catch (o) {
      console.error("Error in safelyNotifyBackgroundScript:", o);
    }
  }
  function y() {
    try {
      new MutationObserver((r) => {
        let o = !1;
        r.forEach((n) => {
          n.type === "childList" && (o = Array.from(
            document.querySelectorAll("audio, video")
          ).filter(
            (t) => t instanceof HTMLMediaElement
          ).some(
            (t) => !s.includes(t)
          ));
        }), o && l();
      }).observe(document.body, {
        childList: !0,
        // Watch for added/removed elements
        subtree: !0
        // Watch the entire DOM tree
      });
    } catch (e) {
      console.error("Error setting up mutation observer:", e);
    }
  }
  function E() {
    try {
      typeof chrome < "u" && chrome.runtime && chrome.runtime.sendMessage(
        { action: "getAudioStatus" },
        function(e) {
          if (chrome.runtime.lastError) {
            console.error(
              "Error requesting volume:",
              chrome.runtime.lastError
            );
            return;
          }
          e && f(e.volume) && (d(e.volume), console.log(`Applied volume settings: ${e.volume}%`));
        }
      );
    } catch (e) {
      console.error("Error in requestInitialVolume:", e);
    }
  }
  try {
    typeof chrome < "u" && chrome.runtime && chrome.runtime.onMessage && chrome.runtime.onMessage.addListener(function(e, r, o) {
      if (r.id && r.id !== chrome.runtime.id)
        return console.error("Message from unauthorized source:", r.id), !1;
      if (!e || typeof e != "object" || !e.action)
        return console.error("Invalid message format:", e), !1;
      try {
        switch (e.action) {
          case "getAudioStatus":
            g(), l();
            const n = s.some((t) => !t.paused);
            o({
              hasAudio: s.length > 0,
              volume: u,
              isPlaying: n
            });
            break;
          case "setVolume":
            if (!f(e.volume)) {
              console.error("Invalid volume in message:", e.volume), o({ success: !1, error: "Invalid volume" });
              break;
            }
            g(), l(), d(e.volume), o({ success: !0, volume: u });
            break;
          case "toggleMute":
            if (typeof e.muted != "boolean") {
              console.error("Invalid muted state:", e.muted), o({ success: !1, error: "Invalid muted state" });
              break;
            }
            if (g(), l(), e.muted)
              d(0);
            else {
              const t = f(e.previousVolume) ? e.previousVolume : 100;
              d(t);
            }
            o({ success: !0 });
            break;
          case "playPauseAudio":
            const a = document.querySelector(
              "audio, video"
            );
            if (a && a instanceof HTMLMediaElement) {
              const t = !a.paused;
              try {
                a.paused ? a.play().then(() => {
                  o({
                    success: !0,
                    isPlaying: !0
                  });
                }).catch((m) => {
                  console.error("Error playing media:", m), o({
                    success: !1,
                    error: String(m)
                  });
                }) : (a.pause(), o({
                  success: !0,
                  isPlaying: !1
                }));
              } catch (m) {
                console.error("Error in playPause:", m), o({
                  success: !1,
                  error: String(m)
                });
              }
              return !0;
            } else
              o({
                success: !1,
                error: "No valid media element found"
              });
            break;
          default:
            console.warn("Unknown action:", e.action), o({ success: !1, error: "Unknown action" });
        }
      } catch (n) {
        console.error("Error handling message:", n), o({ success: !1, error: String(n) });
      }
      return !0;
    });
  } catch (e) {
    console.error("Error setting up message listener:", e);
  }
  function v() {
    try {
      g(), l(), y(), h("contentScriptReady"), setTimeout(E, 500), setInterval(l, 5e3);
    } catch (e) {
      console.error("Error in initialize:", e);
    }
  }
  window.addEventListener("error", (e) => {
    e.error && e.error.message && e.error.message.includes("Extension context invalidated") && console.log(
      "Extension was reloaded - continuing with basic audio functionality"
    );
  }), v(), console.log("Volume controller content script loaded");
})();
