const p = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map(), D = 3, y = 50, a = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Map();
chrome.storage.local.get(null, (e) => {
  if (chrome.runtime.lastError) {
    console.error("Error loading storage:", chrome.runtime.lastError);
    return;
  }
  try {
    Object.keys(e).forEach((r) => {
      if (r.startsWith("tab-volume-")) {
        const o = parseInt(r.replace("tab-volume-", ""));
        !isNaN(o) && o > 0 && a.set(o, M(e[r]));
      }
      if (r.startsWith("url-volume-")) {
        const o = r.replace("url-volume-", "");
        o && v.set(o, M(e[r]));
      }
    });
  } catch (r) {
    console.error("Error processing stored settings:", r);
  }
});
function M(e) {
  const r = T();
  return !e || typeof e != "object" ? r : {
    volume: b(e.volume) ? e.volume : r.volume,
    previousVolume: b(e.previousVolume) ? e.previousVolume : r.previousVolume,
    muted: typeof e.muted == "boolean" ? e.muted : r.muted,
    hasAudio: typeof e.hasAudio == "boolean" ? e.hasAudio : r.hasAudio,
    isPlaying: typeof e.isPlaying == "boolean" ? e.isPlaying : void 0,
    tabUrl: typeof e.tabUrl == "string" ? e.tabUrl : void 0
  };
}
function b(e) {
  return typeof e == "number" && !isNaN(e) && e >= 0 && e <= 100;
}
function E(e, r, o) {
  if (!c(e)) {
    console.error("Invalid tabId for saving:", e);
    return;
  }
  try {
    const u = `tab-volume-${e}`;
    if (chrome.storage.local.set({ [u]: r }, () => {
      chrome.runtime.lastError && console.error("Error saving tab volume:", chrome.runtime.lastError);
    }), o) {
      r.tabUrl = o;
      const s = `url-volume-${o}`;
      chrome.storage.local.set({ [s]: r }, () => {
        chrome.runtime.lastError && console.error("Error saving URL volume:", chrome.runtime.lastError);
      }), v.set(o, r);
    }
  } catch (u) {
    console.error("Error in saveTabVolume:", u);
  }
}
function c(e) {
  return typeof e == "number" && !isNaN(e) && e > 0;
}
function T() {
  return {
    volume: 100,
    // 100% volume by default
    previousVolume: 100,
    // 100% previous volume by default
    muted: !1,
    // Not muted by default
    hasAudio: !0
    // Assume tab has audio capabilities
  };
}
function g(e, r) {
  if (!c(e))
    return console.warn("Invalid tabId in getVolumeDataForTab:", e), T();
  try {
    if (a.has(e))
      return a.get(e);
    if (r && v.has(r)) {
      const o = v.get(r);
      return a.set(e, o), E(e, o, r), o;
    }
  } catch (o) {
    console.error("Error in getVolumeDataForTab:", o);
  }
  return T();
}
function S(e, r, o = 0) {
  if (!c(e)) {
    console.error("Invalid tabId for sending message:", e);
    return;
  }
  if (!r || typeof r != "object" || !r.action) {
    console.error("Invalid message format:", r);
    return;
  }
  if (o >= D) {
    console.log(`Max retries reached for tab ${e}, giving up.`);
    return;
  }
  try {
    chrome.tabs.sendMessage(e, r, (u) => {
      if (chrome.runtime.lastError) {
        console.log(
          `Error sending message to tab ${e}: ${chrome.runtime.lastError.message}`
        ), f.has(e) || f.set(e, []);
        const s = f.get(e);
        s.length < y ? s.push({
          message: r,
          retryCount: o + 1,
          time: Date.now()
        }) : console.warn(`Message queue overflow for tab ${e}`);
        return;
      }
      console.log(`Message sent successfully to tab ${e}`);
    });
  } catch (u) {
    console.error(`Error sending message to tab ${e}:`, u);
  }
}
function w(e) {
  if (!c(e) || !f.has(e)) return;
  const r = f.get(e);
  if (r.length !== 0)
    try {
      const o = Date.now(), u = [...r].slice(0, y);
      f.set(e, []), u.forEach((s) => {
        if (!s.message || typeof s.message != "object" || !s.message.action) {
          console.error("Invalid queued message:", s.message);
          return;
        }
        if (o - s.time >= 1e3 && o - s.time < 6e4)
          S(e, s.message, s.retryCount);
        else if (o - s.time < 1e3) {
          const h = f.get(e);
          h.length < y ? h.push(s) : console.warn("Message queue overflow for tab", e);
        } else
          console.warn("Discarding old message for tab", e);
      });
    } catch (o) {
      console.error("Error processing message queue:", o);
    }
}
setInterval(() => {
  try {
    f.forEach((e, r) => {
      w(r);
    });
  } catch (e) {
    console.error("Error in message queue interval:", e);
  }
}, 2e3);
function A(e, r) {
  if (!c(e)) {
    console.error("Invalid tabId for applying volume:", e);
    return;
  }
  try {
    const o = {
      action: r.muted ? "toggleMute" : "setVolume",
      volume: r.volume,
      muted: r.muted,
      previousVolume: r.previousVolume
    };
    S(e, o);
  } catch (o) {
    console.error("Error in applyVolumeToTab:", o);
  }
}
chrome.tabs.onUpdated.addListener((e, r, o) => {
  if (c(e))
    try {
      if (r.status === "complete" && setTimeout(() => {
        w(e);
      }, 1e3), r.audible !== void 0) {
        if (console.log(`Tab ${e} audible: ${r.audible}`), r.audible) {
          p.add(e);
          const u = g(e, o.url);
          u.hasAudio = !0, a.set(e, u), E(e, u, o.url), setTimeout(() => {
            A(e, u);
          }, 1e3);
        } else
          p.delete(e);
        try {
          chrome.runtime.sendMessage(
            {
              action: "tabAudibleChanged",
              tabId: e,
              audible: r.audible,
              tab: o
            },
            () => {
              chrome.runtime.lastError;
            }
          );
        } catch (u) {
          console.error("Error notifying popup:", u);
        }
      }
      if (r.url && o.id) {
        const u = r.url;
        if (v.has(u)) {
          const s = v.get(u);
          a.set(o.id, s), o.audible && setTimeout(() => {
            A(o.id, s);
          }, 1e3);
        }
      }
    } catch (u) {
      console.error("Error in tabs.onUpdated handler:", u);
    }
});
chrome.tabs.onRemoved.addListener((e) => {
  if (c(e))
    try {
      p.delete(e), a.delete(e), f.delete(e);
    } catch (r) {
      console.error("Error in tabs.onRemoved handler:", r);
    }
});
chrome.runtime.onMessage.addListener((e, r, o) => {
  var u, s, h;
  if (r.id && r.id !== chrome.runtime.id)
    return console.error("Message from unauthorized source:", r.id), !1;
  if (!e || typeof e != "object" || !e.action)
    return console.error("Invalid message format:", e), !1;
  try {
    if (e.action === "contentScriptReady" && ((u = r.tab) != null && u.id)) {
      const t = r.tab.id;
      return c(t) ? (console.log(`Content script ready in tab ${t}`), w(t), o({ success: !0 }), !0) : (console.error("Invalid tabId in contentScriptReady:", t), o({ success: !1, error: "Invalid tabId" }), !0);
    }
    if (e.action === "getAudibleTabs") {
      const t = /* @__PURE__ */ new Set([
        ...p,
        ...a.keys()
      ]);
      return chrome.tabs.query({}, (n) => {
        try {
          const d = n.filter(
            (l) => l.id && c(l.id) && (p.has(l.id) || a.has(l.id) && a.get(l.id).hasAudio || l.url && v.has(l.url))
          ).map((l) => {
            const m = g(l.id, l.url);
            return {
              ...l,
              volumeData: m
            };
          });
          o({ tabs: d });
        } catch (i) {
          console.error("Error processing getAudibleTabs:", i), o({ tabs: [], error: String(i) });
        }
      }), !0;
    }
    if (e.action === "updateTabVolume") {
      const { tabId: t, volume: n, muted: i, previousVolume: d } = e;
      return c(t) ? n !== void 0 && !b(n) ? (console.error("Invalid volume in updateTabVolume:", n), o({ success: !1, error: "Invalid volume" }), !0) : d !== void 0 && !b(d) ? (console.error(
        "Invalid previousVolume in updateTabVolume:",
        d
      ), o({ success: !1, error: "Invalid previousVolume" }), !0) : i !== void 0 && typeof i != "boolean" ? (console.error("Invalid muted state in updateTabVolume:", i), o({ success: !1, error: "Invalid muted state" }), !0) : (chrome.tabs.get(t, (l) => {
        try {
          if (chrome.runtime.lastError) {
            console.error("Error getting tab info:", chrome.runtime.lastError), o({
              success: !1,
              error: chrome.runtime.lastError.message
            });
            return;
          }
          const m = g(t, l.url), V = {
            ...m,
            volume: n !== void 0 ? n : m.volume,
            muted: i !== void 0 ? i : m.muted,
            previousVolume: d !== void 0 ? d : m.previousVolume,
            hasAudio: !0
          };
          a.set(t, V), E(t, V, l.url), A(t, V), o({ success: !0 });
        } catch (m) {
          console.error("Error in updateTabVolume:", m), o({ success: !1, error: String(m) });
        }
      }), !0) : (console.error("Invalid tabId in updateTabVolume:", t), o({ success: !1, error: "Invalid tabId" }), !0);
    }
    if (e.action === "getAudioStatus" && ((s = r.tab) != null && s.id)) {
      const t = r.tab.id;
      if (!c(t))
        return console.error("Invalid tabId in getAudioStatus:", t), o({ success: !1, error: "Invalid tabId" }), !0;
      const n = r.tab.url, i = g(t, n);
      return o({
        volume: i.volume,
        muted: i.muted,
        previousVolume: i.previousVolume
      }), !0;
    }
    if (e.action === "updateTabStatus" && ((h = r.tab) != null && h.id)) {
      const t = r.tab.id;
      if (!c(t))
        return console.error("Invalid tabId in updateTabStatus:", t), o({ success: !1, error: "Invalid tabId" }), !0;
      const n = r.tab.url;
      if (typeof e.hasAudio != "boolean")
        return console.error("Invalid hasAudio value:", e.hasAudio), o({ success: !1, error: "Invalid hasAudio value" }), !0;
      const i = g(t, n);
      return i.hasAudio = e.hasAudio, a.set(t, i), E(t, i, n), o({ success: !0 }), !0;
    }
  } catch (t) {
    console.error("Error handling message:", t), o({ success: !1, error: String(t) });
  }
  return o({ success: !1, error: "Unknown action" }), !0;
});
console.log("Volume controller background script initialized");
